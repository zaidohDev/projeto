 
<div id="sidebar-wrapper" class="col-md-3" style="padding-left: 0;padding-right: 0">
    <ul class="sidebar-nav">
        <li class="sidebar-brand">
            <a href="<?php echo e(url('home')); ?>">
                <h4>Área Administrativa</h4>
            </a>
        </li>
       <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </ul>
</div>


<style>

*::before, *::after {
    box-sizing: border-box;
}
*::before, *::after {
    box-sizing: border-box;
}
ul.sidebar-nav li a.active, ul.sidebar-nav li a:hover, ul.sidebar-nav li a:focus {
    background-color: rgba(255, 255, 255, 0.2);
    color: #ffffff;
    display: block;
    transition: all 0.3s ease 0s;
}
.sidebar_active, ul.sidebar-nav li a.active, ul.sidebar-nav li a:hover, ul.sidebar-nav li a:focus, ul.sidebar-nav li ul.sub li a:hover, ul.sidebar-nav li ul.sub li.active a {
    background-color: rgba(255, 255, 255, 0.2);
    color: white;
    display: block;
    transition: all 0.3s ease 0s;
}
ul.sidebar-nav li a.active, ul.sidebar-nav li a:hover, ul.sidebar-nav li a:focus {
    background: #e99755 none repeat scroll 0 0;
    color: #e54d42;
    display: block;
    transition: all 0.3s ease 0s;
    text-decoration: none;
    text-shadow: 1px 1px #8e44ad;
}
ul.sidebar-nav li a {
    color: #ffffff;
    display: block;
    font-size: 12px;
    outline: medium none;
    padding: 18px 0 18px 25px;
    text-decoration: none;
    transition: all 0.3s ease 0s;
}
ul.sidebar-nav li a {
    color: white;
    display: block;
    font-size: 12px;
    outline: medium none;
    padding: 18px 0 18px 25px;
    text-decoration: none;
    transition: all 0.3s ease 0s;
}
ul.sidebar-nav li a {
    color: #aeb2b7;
    display: block;
    font-size: 12px;
    outline: medium none;
    padding: 18px 0 18px 25px;
    text-decoration: none;
    transition: all 0.3s ease 0s;
}
a, a:hover, a:focus {
    outline: medium none;
    text-decoration: none;
}
a {
    color: #32323a;
}
a {
    color: #428bca;
    text-decoration: none;
}
a {
    background: transparent none repeat scroll 0 0;
}
* {
    box-sizing: border-box;
}
*::-moz-selection {
    background: #253dab none repeat scroll 0 0;
    color: #fff;
}
*::-moz-selection {
    background: #33d4c7 none repeat scroll 0 0;
    color: white;
}
*::-moz-selection {
    background: #33d4c7 none repeat scroll 0 0;
    color: #fff;
}

.fa-calendar-o::before {
    content: "";
}
.fa-pencil::before {
    content: "";
}
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												
</style>
