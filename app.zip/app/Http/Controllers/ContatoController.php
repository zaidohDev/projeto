<?php

namespace App\Http\Controllers;

class ContatoController extends Controller {

	public function index() {
		return view('contato.index');
	}
}
